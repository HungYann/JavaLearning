package com.hongyang.maven;

import org.junit.Test;
import static junit.framework.Assert.*;

public class HelloWorldTest {
	@Test
	public void testHelloWorld() {
		HelloWorld hello = new HelloWorld();
		String result = hello.sayHello("liu"); //断言
		assertEquals("Helloliu", result);
	}
}
